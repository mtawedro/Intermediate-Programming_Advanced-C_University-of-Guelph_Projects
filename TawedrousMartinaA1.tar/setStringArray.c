#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void setStringArray ( char **array, int index, char *string )
{
	
    array[index] = malloc(sizeof(char) * strlen(string)+1);
    strncpy(array[index],string, strlen(string)+1); 
	
	
}
