#ifndef ARRAYVARS_H
#define ARRAYVARS_H

    int width;

#endif
