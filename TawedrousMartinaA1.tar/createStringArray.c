#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char **createStringArray ( int number )
{
    char **arrayPtrs;
	
    arrayPtrs= malloc(sizeof(char*) * number);

    return arrayPtrs;

}
