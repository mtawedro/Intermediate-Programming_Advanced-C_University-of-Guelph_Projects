#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arrayVars.h"

void set2DElement ( int *array, int row, int col, int value )
{
	
    if(row==0)
	{
	
	    array[(width * row) + col] = value;
	
	    width++;
    }

    else
    {
        array[(width * row) + col] = value;
	
    }
	
}
