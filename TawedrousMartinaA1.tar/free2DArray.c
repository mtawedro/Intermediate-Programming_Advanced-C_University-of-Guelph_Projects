#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void free2DArray ( int *array ) 
{
	
    free(array); 
	
	
}
