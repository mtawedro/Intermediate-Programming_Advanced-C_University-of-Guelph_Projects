#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *getStringArray ( char **array, int index )
{
	
    return array[index];
	
	
}
