#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int width = 0;

int *create2DArray ( int rows, int cols )
{
	int *array;
	
	array= malloc(sizeof(int) *(rows * cols));
	
	return array;
	
}
