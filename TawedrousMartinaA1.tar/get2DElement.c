#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arrayVars.h"

int get2DElement ( int *array, int row, int col )
{
	
	

    return array[(width * row) + col];
   
	
	
}
