#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int **createArray ( int rows, int cols )
{
    int i;
		
    int **array;
	
    array= malloc(sizeof(int*) * rows);
	
	 for(i = 0;i<rows; i++) {

		 array[i]=malloc(sizeof (int) * cols);
		 
    }
	  

    return array; 
}
