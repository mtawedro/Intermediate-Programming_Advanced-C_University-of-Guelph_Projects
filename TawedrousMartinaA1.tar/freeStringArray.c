#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void freeStringArray ( char **array, int number ) 
{
    int x;
    for(x = 0; x<number;x++){
		
		free(array[x]);

	} 
	
	free(array);
	
}
